export interface ServiceItem {
  id: string;
  title: string;
  shortDesc: string;
  duration: string;
  badge: string;
  image: string;
  highlight: string;
}

export interface ProductItem {
  id: string;
  name: string;
  category: string;
  price: number;
  weightOrSize: string;
  image: string;
  description: string;
  inStock: boolean;
}

export interface CartItem {
  product: ProductItem;
  quantity: number;
}

export interface TestimonialItem {
  id: string;
  author: string;
  pet: string;
  neighborhood: string;
  content: string;
  rating: number;
}

export interface GalleryPhoto {
  id: string;
  title: string;
  category: 'banho' | 'veterinaria' | 'daycare' | 'felinos';
  categoryLabel: string;
  imageUrl: string;
  alt: string;
}
