import { ServiceItem, ProductItem, TestimonialItem, GalleryPhoto } from '../types';

export const BUSINESS_INFO = {
  name: 'Pet Shop Estação Animal',
  slogan: 'O cuidado que seu melhor amigo merece.',
  phoneRaw: '5591981316607',
  phoneDisplay: '(91) 98131-6607',
  address: 'Tv. dos Tupinambás, 262 - Batista Campos, Belém - PA, 66025-610',
  mapsUrl: 'https://maps.google.com/?q=Tv.+dos+Tupinambas,+262+-+Batista+Campos,+Belem+-+PA,+66025-610',
};

export const createWhatsAppUrl = (message: string) => {
  return `https://wa.me/${BUSINESS_INFO.phoneRaw}?text=${encodeURIComponent(message)}`;
};

export const SERVICES: ServiceItem[] = [
  {
    id: 'banho-hidratacao',
    title: 'Banho & Hidratação Calmante',
    shortDesc: 'Toalhas esterilizadas, água morna e produtos botânicos hipoalergênicos.',
    duration: '45 - 60 min',
    badge: 'Mais pedido',
    image: '/src/assets/images/hero_pet_grooming_1794074704949.jpg',
    highlight: 'Aromaterapia relaxante e secagem silenciosa',
  },
  {
    id: 'tosa-tesoura',
    title: 'Tosa na Tesoura & Padrão',
    shortDesc: 'Finalização artística respeitando o padrão da raça e anatomia do seu pet.',
    duration: '60 - 90 min',
    badge: 'Especialidade',
    image: '/src/assets/images/gallery_happy_dog_1794074706108.jpg',
    highlight: 'Profissionais especialistas em tesoura',
  },
  {
    id: 'consulta-veterinaria',
    title: 'Consulta Veterinária Preventiva',
    shortDesc: 'Atendimento clínico empático, exames preventivos e acompanhamento contínuo.',
    duration: '40 min',
    badge: 'Saúde & Bem-Estar',
    image: '/src/assets/images/service_vet_care_1794074705237.jpg',
    highlight: 'Avaliação clínica minuciosa sem pressa',
  },
  {
    id: 'daycare-recreacao',
    title: 'Daycare & Socialização',
    shortDesc: 'Enriquecimento ambiental, brincadeiras monitoradas e gasto de energia saudável.',
    duration: 'Diária ou Turno',
    badge: 'Espaço Amplo',
    image: '/src/assets/images/service_daycare_play_1794074721604.jpg',
    highlight: 'Monitores treinados em comportamento canino',
  },
  {
    id: 'spa-felino',
    title: 'Spa Silencioso para Gatos',
    shortDesc: 'Sala exclusiva isolada de latidos, difusores de feromônio e manuseio suave.',
    duration: '45 min',
    badge: 'Exclusivo Felinos',
    image: '/src/assets/images/service_cat_spa_1794074721733.jpg',
    highlight: 'Protocolo Cat Friendly sem estresse',
  },
  {
    id: 'taxi-dog',
    title: 'Táxi Dog Climatizado',
    shortDesc: 'Buscamos e levamos seu pet com caixas de transporte seguras em Belém.',
    duration: 'Agendado',
    badge: 'Comodidade',
    image: '/src/assets/images/product_dog_toy_accessory_1794074705749.jpg',
    highlight: 'Veículo com ar-condicionado e cintos certificados',
  },
];

export const PRODUCTS: ProductItem[] = [
  {
    id: 'racao-nourish-lamb',
    name: 'Ração Super Premium Cordeiro & Batata Doce',
    category: 'Alimentação Natural',
    price: 168.90,
    weightOrSize: '2.5 kg',
    image: '/src/assets/images/product_premium_kibble_1794074705241.jpg',
    description: 'Fórmula sem grãos, rica em proteínas nobres, prebióticos e ômegas 3 e 6 para pelagem radiante.',
    inStock: true,
  },
  {
    id: 'shampoo-botanico-camomila',
    name: 'Kit Shampoo & Condicionador Botânico',
    category: 'Higiene & Bem-Estar',
    price: 74.50,
    weightOrSize: '473 ml cada',
    image: '/src/assets/images/product_natural_shampoo_1794074722091.jpg',
    description: 'Extrato natural de aveia coloidal e camomila. Acalma a pele sensível e deixa perfume suave.',
    inStock: true,
  },
  {
    id: 'coleira-guia-couro',
    name: 'Conjunto Coleira & Guia em Couro Legítimo',
    category: 'Passeio & Acessórios',
    price: 129.00,
    weightOrSize: 'Tamanho M / Ajustável',
    image: '/src/assets/images/product_dog_toy_accessory_1794074705749.jpg',
    description: 'Acabamento artesanal, costura reforçada e mosquetão em latão maciço com trava de segurança.',
    inStock: true,
  },
  {
    id: 'mordedor-corda-algodao',
    name: 'Mordedor Trançado em Algodão Orgânico',
    category: 'Brinquedos & Estímulo',
    price: 38.00,
    weightOrSize: '35 cm',
    image: '/src/assets/images/product_dog_toy_accessory_1794074705749.jpg',
    description: 'Fibras 100% naturais que auxiliam na higiene bucal e limpeza do tártaro durante a mastigação.',
    inStock: true,
  },
];

export const GALLERY_PHOTOS: GalleryPhoto[] = [
  {
    id: 'gal-1',
    title: 'Banho relaxante com espuma suave',
    category: 'banho',
    categoryLabel: 'Banho & Tosa',
    imageUrl: '/src/assets/images/hero_pet_grooming_1794074704949.jpg',
    alt: 'Golden retriever recebendo banho e massagem com espuma suave na Estação Animal',
  },
  {
    id: 'gal-2',
    title: 'Finalização de tosa com bandana',
    category: 'banho',
    categoryLabel: 'Banho & Tosa',
    imageUrl: '/src/assets/images/gallery_happy_dog_1794074706108.jpg',
    alt: 'Pastor australiano feliz após tosa estética com bandana laranja',
  },
  {
    id: 'gal-3',
    title: 'Check-up com acolhimento veterinário',
    category: 'veterinaria',
    categoryLabel: 'Veterinária',
    imageUrl: '/src/assets/images/service_vet_care_1794074705237.jpg',
    alt: 'Veterinária examinando gatinho dócil no consultório da Estação Animal',
  },
  {
    id: 'gal-4',
    title: 'Tarde de recreação no Daycare',
    category: 'daycare',
    categoryLabel: 'Daycare',
    imageUrl: '/src/assets/images/service_daycare_play_1794074721604.jpg',
    alt: 'Cachorros socializando e brincando no daycare com monitora',
  },
  {
    id: 'gal-5',
    title: 'Escovação relaxante para felinos',
    category: 'felinos',
    categoryLabel: 'Spa Felino',
    imageUrl: '/src/assets/images/service_cat_spa_1794074721733.jpg',
    alt: 'Gato persa relaxando durante escovação em ambiente tranquilo',
  },
  {
    id: 'gal-6',
    title: 'Nutrição e bem-estar no balcão',
    category: 'veterinaria',
    categoryLabel: 'Produtos',
    imageUrl: '/src/assets/images/product_premium_kibble_1794074705241.jpg',
    alt: 'Rações super premium e petiscos naturais na Estação Animal',
  },
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'dep-1',
    author: 'Camila Vasconcelos',
    pet: 'Tutora da Mel (Golden Retriever)',
    neighborhood: 'Batista Campos, Belém',
    content: 'O cuidado no banho da Mel é incomparável. Ela volta cheirosa, calma e com o pelo macio por dias. Não troco a Estação Animal por nenhum outro.',
    rating: 5,
  },
  {
    id: 'dep-2',
    author: 'Dr. Roberto Mendes',
    pet: 'Tutor do Fred e Bento (Pugs)',
    neighborhood: 'Batista Campos, Belém',
    content: 'A equipe veterinária é atenciosa demais. Ter profissionais que tratam nossos bichinhos como família bem aqui na Tupinambás traz uma paz imensa.',
    rating: 5,
  },
  {
    id: 'dep-3',
    author: 'Larissa Pinheiro',
    pet: 'Tutora do Sushi (Gato Persa)',
    neighborhood: 'Batista Campos, Belém',
    content: 'O atendimento felino silencioso é um diferencial real em Belém. Meu gato costumava tremer em pet shops, mas aqui ele fica sereno do início ao fim.',
    rating: 5,
  },
];
