import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Maximize2, X, Sparkles } from 'lucide-react';
import { GALLERY_PHOTOS } from '../data/petData';
import { GalleryPhoto } from '../types';

export const GallerySection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [activePhoto, setActivePhoto] = useState<GalleryPhoto | null>(null);

  const categories = [
    { id: 'todos', label: 'Todos os Momentos' },
    { id: 'banho', label: 'Banho & Tosa' },
    { id: 'veterinaria', label: 'Veterinária' },
    { id: 'daycare', label: 'Daycare' },
    { id: 'felinos', label: 'Spa Felino' },
  ];

  const filteredPhotos = selectedCategory === 'todos'
    ? GALLERY_PHOTOS
    : GALLERY_PHOTOS.filter((p) => p.category === selectedCategory);

  return (
    <section id="galeria" className="py-24 sm:py-32 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mx-auto text-center mb-12 sm:mb-16">
          <span className="text-xs font-bold uppercase tracking-wider text-[#EA580C] bg-orange-50 px-3 py-1 rounded-full">
            Nosso Dia a Dia
          </span>
          <h2 className="mt-4 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 tracking-tight">
            Momentos Felizes
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600 font-body">
            Veja a tranquilidade e a alegria dos nossos pequenos hóspedes e clientes.
          </p>
        </div>

        {/* Clean Filter Segmented Control */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                type="button"
                className={`px-4 py-2 rounded-full text-xs sm:text-sm font-semibold transition-all ${
                  isActive
                    ? 'bg-[#EA580C] text-white shadow-md shadow-orange-600/20'
                    : 'bg-[#FAF8F5] text-slate-600 hover:text-slate-900 hover:bg-orange-100/50'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* Gallery Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence>
            {filteredPhotos.map((photo) => (
              <motion.div
                key={photo.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
                className="group relative aspect-[4/3] rounded-3xl overflow-hidden bg-slate-100 cursor-pointer shadow-xs hover:shadow-xl hover:shadow-orange-950/10 transition-all duration-300"
                onClick={() => setActivePhoto(photo)}
              >
                <img
                  src={photo.imageUrl}
                  alt={photo.alt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                
                {/* Overlay on hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                  <span className="text-xs font-semibold text-orange-300 tracking-wide">
                    {photo.categoryLabel}
                  </span>
                  <h4 className="font-display text-white text-base font-bold">
                    {photo.title}
                  </h4>
                  <div className="mt-2 inline-flex items-center gap-1.5 text-xs text-white/80 font-medium">
                    <Maximize2 className="w-3.5 h-3.5 text-white" />
                    <span>Clique para ampliar</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {activePhoto && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200"
            onClick={() => setActivePhoto(null)}
          >
            <div
              className="relative max-w-4xl w-full bg-white rounded-3xl overflow-hidden shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setActivePhoto(null)}
                aria-label="Fechar visualização"
                type="button"
                className="absolute top-4 right-4 z-10 p-2.5 rounded-full bg-black/60 hover:bg-black text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="aspect-[16/10] bg-black">
                <img
                  src={activePhoto.imageUrl}
                  alt={activePhoto.alt}
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="p-6 bg-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-bold text-[#EA580C] uppercase tracking-wider">
                    {activePhoto.categoryLabel}
                  </span>
                  <h3 className="font-display text-lg font-bold text-slate-900 mt-0.5">
                    {activePhoto.title}
                  </h3>
                  <p className="text-xs text-slate-500 font-body mt-1">
                    {activePhoto.alt}
                  </p>
                </div>

                <button
                  onClick={() => setActivePhoto(null)}
                  type="button"
                  className="px-5 py-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold font-display transition-colors"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};
