import React from 'react';
import { motion } from 'motion/react';
import { MessageCircle, Clock, Sparkles } from 'lucide-react';
import { SERVICES, createWhatsAppUrl } from '../data/petData';

export const ServicesSection: React.FC = () => {
  return (
    <section id="servicos" className="py-24 sm:py-32 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with generous breathing space */}
        <div className="max-w-2xl mx-auto text-center mb-16 sm:mb-20">
          <span className="text-xs font-bold uppercase tracking-wider text-[#EA580C] bg-orange-50 px-3 py-1 rounded-full">
            Nossos Cuidados
          </span>
          <h2 className="mt-4 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 tracking-tight">
            Serviços Feitos com Amor
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600 font-body">
            Cada detalhe pensado para o conforto, saúde e alegria do seu pet.
          </p>
        </div>

        {/* 6 Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-10">
          {SERVICES.map((service, index) => {
            const serviceWhatsAppUrl = createWhatsAppUrl(
              `Olá! Gostaria de agendar o serviço "${service.title}" na Estação Animal.`
            );

            return (
              <motion.article
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: index * 0.08 }}
                className="group flex flex-col bg-[#FAF8F5] rounded-3xl overflow-hidden border border-orange-950/5 hover:border-orange-500/30 hover:shadow-xl hover:shadow-orange-950/5 transition-all duration-300"
              >
                {/* Photo Header */}
                <div className="relative aspect-[16/10] overflow-hidden bg-slate-100">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                  <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-xs px-3 py-1 rounded-full text-xs font-semibold text-slate-800 shadow-xs">
                    {service.badge}
                  </div>
                </div>

                {/* Content Body */}
                <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs text-slate-500 font-body">
                      <Clock className="w-3.5 h-3.5 text-orange-500" />
                      <span>{service.duration}</span>
                    </div>

                    <h3 className="font-display text-xl font-bold text-slate-900 group-hover:text-[#EA580C] transition-colors">
                      {service.title}
                    </h3>

                    <p className="text-sm text-slate-600 font-body leading-relaxed">
                      {service.shortDesc}
                    </p>
                  </div>

                  {/* Highlight feature */}
                  <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between">
                    <span className="text-xs text-orange-800/80 font-medium">
                      ✓ {service.highlight}
                    </span>
                  </div>

                  {/* Direct WhatsApp Action */}
                  <a
                    href={serviceWhatsAppUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-white hover:bg-[#EA580C] text-slate-800 hover:text-white font-display text-sm font-semibold border border-orange-200/80 hover:border-transparent transition-all shadow-xs group-hover:shadow-md"
                  >
                    <MessageCircle className="w-4 h-4 text-orange-500 group-hover:text-white transition-colors" />
                    <span>Agendar no WhatsApp</span>
                  </a>
                </div>
              </motion.article>
            );
          })}
        </div>

      </div>
    </section>
  );
};
