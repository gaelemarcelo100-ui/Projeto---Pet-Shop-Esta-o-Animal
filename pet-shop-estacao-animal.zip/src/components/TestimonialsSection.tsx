import React from 'react';
import { motion } from 'motion/react';
import { Star, Quote, Heart } from 'lucide-react';
import { TESTIMONIALS } from '../data/petData';

export const TestimonialsSection: React.FC = () => {
  return (
    <section className="py-24 sm:py-32 bg-[#FAF8F5] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-2xl mx-auto text-center mb-16 sm:mb-20">
          <span className="text-xs font-bold uppercase tracking-wider text-[#EA580C] bg-orange-100/70 px-3 py-1 rounded-full">
            Avaliações Reais
          </span>
          <h2 className="mt-4 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 tracking-tight">
            Quem Ama, Confia
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600 font-body">
            O carinho e a dedicação refletidos no olhar dos tutores de Belém.
          </p>
        </div>

        {/* 3 Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white rounded-3xl p-8 border border-orange-950/5 shadow-xs hover:shadow-xl hover:shadow-orange-950/5 transition-all duration-300 flex flex-col justify-between space-y-6"
            >
              <div className="space-y-4">
                {/* 5 Stars */}
                <div className="flex items-center gap-1 text-amber-400">
                  {[...Array(item.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>

                <p className="text-slate-700 font-body text-base leading-relaxed italic">
                  "{item.content}"
                </p>
              </div>

              {/* Author & Pet */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <h4 className="font-display text-base font-bold text-slate-900">
                    {item.author}
                  </h4>
                  <p className="text-xs font-medium text-orange-700/90 font-body">
                    {item.pet}
                  </p>
                  <p className="text-[11px] text-slate-400 font-body">
                    {item.neighborhood}
                  </p>
                </div>
                <div className="w-8 h-8 rounded-full bg-orange-50 flex items-center justify-center text-[#EA580C]">
                  🐾
                </div>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};
