import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Trash2, Plus, Minus, ShoppingBag, MessageCircle, ArrowRight } from 'lucide-react';
import { CartItem } from '../types';
import { BUSINESS_INFO, createWhatsAppUrl } from '../data/petData';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const totalAmount = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const handleCheckoutWhatsApp = () => {
    if (items.length === 0) return;

    let message = `*Pedido - Pet Shop Estação Animal*\n\n`;
    message += `Olá! Gostaria de fazer o pedido dos seguintes produtos:\n\n`;

    items.forEach((item, idx) => {
      const itemSubtotal = (item.product.price * item.quantity).toFixed(2).replace('.', ',');
      message += `${idx + 1}. *${item.product.name}*\n`;
      message += `   Qtd: ${item.quantity}x | Subtotal: R$ ${itemSubtotal}\n`;
    });

    message += `\n*Total do Pedido: R$ ${totalAmount.toFixed(2).replace('.', ',')}*\n\n`;
    message += `Gostaria de combinar a entrega ou retirada na Tv. dos Tupinambás, 262!`;

    const url = createWhatsAppUrl(message);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs"
          />

          {/* Slide-over panel */}
          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 26, stiffness: 260 }}
            className="fixed top-0 right-0 bottom-0 z-50 w-full max-w-md bg-white shadow-2xl flex flex-col"
          >
            {/* Header */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-orange-100 text-[#EA580C] flex items-center justify-center">
                  <ShoppingBag className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-display text-lg font-bold text-slate-900">
                    Sacola de Pedidos
                  </h3>
                  <p className="text-xs text-slate-500 font-body">
                    {items.length === 0
                      ? 'Nenhum item adicionado'
                      : `${items.reduce((acc, i) => acc + i.quantity, 0)} itens`}
                  </p>
                </div>
              </div>

              <button
                onClick={onClose}
                aria-label="Fechar sacola"
                type="button"
                className="p-2 rounded-full hover:bg-slate-100 text-slate-500 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content / Items List */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {items.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-4">
                  <div className="w-16 h-16 rounded-full bg-orange-50 flex items-center justify-center text-2xl">
                    🛍️
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-display text-base font-bold text-slate-800">
                      Sua sacola está vazia
                    </h4>
                    <p className="text-xs text-slate-500 font-body max-w-xs">
                      Adicione itens da nossa boutique ou agende banho e tosa para o seu melhor amigo.
                    </p>
                  </div>
                  <button
                    onClick={onClose}
                    type="button"
                    className="px-6 py-2.5 rounded-full bg-orange-100 hover:bg-orange-200 text-[#EA580C] font-display text-xs font-bold transition-colors"
                  >
                    Ver Produtos
                  </button>
                </div>
              ) : (
                items.map((item) => (
                  <div
                    key={item.product.id}
                    className="flex gap-4 p-3 rounded-2xl bg-[#FAF8F5] border border-orange-950/5 items-center"
                  >
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-16 h-16 rounded-xl object-cover shrink-0 bg-white"
                      referrerPolicy="no-referrer"
                    />

                    <div className="flex-1 min-w-0">
                      <h4 className="font-display text-sm font-bold text-slate-900 truncate">
                        {item.product.name}
                      </h4>
                      <p className="text-xs font-semibold text-[#EA580C] font-display mt-0.5 tabular-nums">
                        R$ {(item.product.price * item.quantity).toFixed(2).replace('.', ',')}
                      </p>

                      <div className="flex items-center gap-3 mt-2">
                        <div className="flex items-center bg-white rounded-lg border border-slate-200 px-1 py-0.5">
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, -1)}
                            aria-label="Diminuir quantidade"
                            className="p-1 hover:text-[#EA580C] transition-colors"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-2 text-xs font-bold text-slate-800 tabular-nums">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, 1)}
                            aria-label="Aumentar quantidade"
                            className="p-1 hover:text-[#EA580C] transition-colors"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <button
                          onClick={() => onRemoveItem(item.product.id)}
                          aria-label="Remover item"
                          className="text-slate-400 hover:text-red-500 transition-colors p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Footer with Total and WhatsApp Checkout */}
            {items.length > 0 && (
              <div className="p-6 border-t border-slate-100 bg-[#FAF8F5] space-y-4">
                <div className="flex items-baseline justify-between">
                  <span className="text-sm font-bold text-slate-700 font-display">Total</span>
                  <span className="text-2xl font-bold text-slate-900 font-display tabular-nums">
                    R$ {totalAmount.toFixed(2).replace('.', ',')}
                  </span>
                </div>

                <button
                  onClick={handleCheckoutWhatsApp}
                  type="button"
                  className="w-full py-4 rounded-full bg-[#EA580C] hover:bg-[#C2410C] text-white font-display text-sm font-bold shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4 fill-white/20" />
                  <span>Pedir no WhatsApp</span>
                </button>

                <p className="text-[11px] text-center text-slate-500 font-body">
                  Você será direcionado ao WhatsApp para confirmar entrega ou retirada.
                </p>
              </div>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
};
