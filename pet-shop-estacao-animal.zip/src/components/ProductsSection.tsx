import React from 'react';
import { motion } from 'motion/react';
import { ShoppingBag, MessageCircle, Check, ArrowRight } from 'lucide-react';
import { PRODUCTS, createWhatsAppUrl } from '../data/petData';
import { ProductItem } from '../types';

interface ProductsSectionProps {
  onAddToCart: (product: ProductItem) => void;
}

export const ProductsSection: React.FC<ProductsSectionProps> = ({ onAddToCart }) => {
  return (
    <section id="produtos" className="py-24 sm:py-32 bg-[#FAF8F5] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mx-auto text-center mb-16 sm:mb-20">
          <span className="text-xs font-bold uppercase tracking-wider text-[#EA580C] bg-orange-100/70 px-3 py-1 rounded-full">
            Boutique & Farmácia
          </span>
          <h2 className="mt-4 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 tracking-tight">
            Produtos Selecionados
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600 font-body">
            Apenas ingredientes nobres, acessórios duráveis e cosméticos seguros para a saúde do pet.
          </p>
        </div>

        {/* 4 Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {PRODUCTS.map((product, index) => {
            const productWhatsAppUrl = createWhatsAppUrl(
              `Olá! Gostaria de comprar o produto "${product.name}" (R$ ${product.price.toFixed(2).replace('.', ',')}) na Estação Animal.`
            );

            return (
              <motion.article
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group flex flex-col bg-white rounded-3xl overflow-hidden border border-orange-950/5 hover:border-orange-500/30 hover:shadow-xl hover:shadow-orange-950/5 transition-all duration-300"
              >
                {/* Product Image Frame */}
                <div className="relative aspect-square overflow-hidden bg-slate-50">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                  <div className="absolute top-3 left-3 bg-white/95 px-2.5 py-1 rounded-full text-[11px] font-semibold text-slate-700 shadow-2xs">
                    {product.weightOrSize}
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-1.5">
                    <span className="text-[11px] font-bold tracking-wider uppercase text-orange-600">
                      {product.category}
                    </span>
                    <h3 className="font-display text-base font-bold text-slate-900 line-clamp-2 leading-snug group-hover:text-[#EA580C] transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-xs text-slate-500 line-clamp-2 font-body">
                      {product.description}
                    </p>
                  </div>

                  {/* Price & Action Buttons */}
                  <div className="pt-3 border-t border-slate-100 space-y-3">
                    <div className="flex items-baseline justify-between">
                      <span className="text-xs text-slate-400 font-medium">Preço</span>
                      <span className="font-display text-xl font-bold text-slate-900 tabular-nums">
                        R$ {product.price.toFixed(2).replace('.', ',')}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => onAddToCart(product)}
                        type="button"
                        className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-orange-50 hover:bg-orange-100 text-[#EA580C] font-display text-xs font-semibold transition-colors focus-visible:ring-2 focus-visible:ring-[#EA580C]"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        <span>Sacola</span>
                      </button>

                      <a
                        href={productWhatsAppUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-[#EA580C] hover:bg-[#C2410C] text-white font-display text-xs font-semibold shadow-xs transition-colors"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>Pedir</span>
                      </a>
                    </div>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </div>

        {/* Custom Order Callout */}
        <div className="mt-14 max-w-3xl mx-auto bg-gradient-to-r from-orange-50 via-amber-50 to-orange-50 p-6 sm:p-8 rounded-3xl border border-orange-200/60 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xs">
          <div className="space-y-1 text-center sm:text-left">
            <h4 className="font-display text-lg font-bold text-slate-900">
              Procurando medicamento ou ração específica?
            </h4>
            <p className="text-sm text-slate-600 font-body">
              Verificamos nosso estoque e separamos para entrega rápida em Belém.
            </p>
          </div>
          <a
            href={createWhatsAppUrl('Olá! Gostaria de consultar a disponibilidade de um produto ou medicamento na Estação Animal.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#EA580C] hover:bg-[#C2410C] text-white font-display text-sm font-semibold shadow-md whitespace-nowrap shrink-0 transition-all hover:scale-105"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Consultar no WhatsApp</span>
          </a>
        </div>

      </div>
    </section>
  );
};
