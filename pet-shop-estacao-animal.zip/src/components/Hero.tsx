import React from 'react';
import { motion } from 'motion/react';
import { MessageCircle, Star, ArrowDown, Sparkles, ShieldCheck } from 'lucide-react';
import { BUSINESS_INFO, createWhatsAppUrl } from '../data/petData';

export const Hero: React.FC = () => {
  const whatsappHeroUrl = createWhatsAppUrl(
    'Olá! Gostaria de agendar um atendimento na Estação Animal no Batista Campos.'
  );

  return (
    <section
      id="inicio"
      className="relative min-h-[92vh] flex items-center pt-24 pb-16 lg:pt-32 lg:pb-24 overflow-hidden"
    >
      {/* Soft background ambient gradient circles */}
      <div className="absolute top-12 left-1/4 w-96 h-96 bg-orange-200/30 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-amber-100/40 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Confident Typography & Direct Action (7 cols) */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 flex flex-col items-start space-y-6 sm:space-y-8"
          >
            {/* Subtle Location Trust Tag */}
            <div className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold tracking-wide text-[#EA580C] bg-orange-100/80 px-3.5 py-1.5 rounded-full">
              <span className="w-2 h-2 rounded-full bg-[#EA580C]" />
              <span>Batista Campos · Belém, PA</span>
            </div>

            {/* Giant Confident Headline */}
            <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-[4rem] font-bold text-slate-900 leading-[1.08] tracking-tight">
              O cuidado que seu <span className="text-[#EA580C] relative inline-block">
                melhor amigo
                <svg
                  className="absolute -bottom-2 left-0 w-full h-3 text-[#EA580C]/30 -z-10"
                  viewBox="0 0 100 12"
                  preserveAspectRatio="none"
                >
                  <path d="M0,8 Q50,0 100,8" stroke="currentColor" strokeWidth="4" fill="none" strokeLinecap="round" />
                </svg>
              </span> merece.
            </h1>

            {/* Concise Supporting Phrase */}
            <p className="text-lg sm:text-xl text-slate-600 font-body leading-relaxed max-w-xl">
              Banho acolhedor, tosa com amor, clínica veterinária e mimos exclusivos na Batista Campos.
            </p>

            {/* Primary Action Button & Social Proof */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto pt-2">
              <a
                href={whatsappHeroUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full bg-[#EA580C] hover:bg-[#C2410C] text-white font-display text-base font-semibold shadow-xl shadow-orange-600/25 hover:shadow-2xl hover:shadow-orange-600/35 hover:-translate-y-0.5 active:translate-y-0 transition-all text-center group"
              >
                <MessageCircle className="w-5 h-5 fill-white/20 group-hover:scale-110 transition-transform" />
                <span>Conversar no WhatsApp</span>
              </a>

              <a
                href="#servicos"
                className="inline-flex items-center justify-center gap-2 px-6 py-4 rounded-full bg-white hover:bg-orange-50/60 text-slate-700 hover:text-[#EA580C] font-display text-base font-semibold border border-slate-200/80 transition-all text-center"
              >
                <span>Ver Serviços</span>
                <span className="text-sm">↓</span>
              </a>
            </div>

            {/* Social Trust Metrics */}
            <div className="pt-2 flex items-center gap-6 text-sm text-slate-600 font-body">
              <div className="flex items-center gap-1.5">
                <div className="flex text-amber-500">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <span className="font-bold text-slate-900 ml-1">4.9/5</span>
              </div>
              <span className="text-slate-300">·</span>
              <span className="text-slate-600">+1.200 pets felizes</span>
              <span className="text-slate-300 hidden sm:inline">·</span>
              <span className="text-slate-600 hidden sm:inline">Zero gaiolas frias</span>
            </div>
          </motion.div>

          {/* Right Column: Hero Visual Masterpiece with Floating Badges (5 cols) */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 relative flex justify-center"
          >
            {/* The Main Hero Image Frame */}
            <div className="relative w-full max-w-md lg:max-w-none aspect-[4/3] lg:aspect-[1/1] rounded-3xl overflow-hidden shadow-2xl shadow-orange-950/15 border-4 border-white bg-white">
              <img
                src="/src/assets/images/hero_pet_grooming_1794074704949.jpg"
                alt="Golden retriever feliz no banho e tosa na Estação Animal"
                className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/30 via-transparent to-transparent pointer-events-none" />
            </div>

            {/* Floating Badge 1 - Top Left */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.6 }}
              className="absolute -top-4 -left-4 sm:-left-6 bg-white/95 backdrop-blur-md px-4 py-2.5 rounded-2xl shadow-lg border border-orange-100 flex items-center gap-2.5"
            >
              <div className="w-8 h-8 rounded-xl bg-orange-100 flex items-center justify-center text-sm">
                🛁
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900 font-display">Banho sem Estresse</p>
                <p className="text-[11px] text-slate-500 font-body">Água quentinha & carinho</p>
              </div>
            </motion.div>

            {/* Floating Badge 2 - Bottom Right */}
            <motion.div
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.55, duration: 0.6 }}
              className="absolute -bottom-5 -right-4 sm:-right-6 bg-white/95 backdrop-blur-md px-4 py-3 rounded-2xl shadow-xl border border-orange-100 flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900 font-display">Clínica Veterinária</p>
                <p className="text-[11px] text-slate-500 font-body">Equipe médica no local</p>
              </div>
            </motion.div>
          </motion.div>

        </div>
      </div>

      {/* Gentle scroll invite indicator */}
      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 hidden md:flex flex-col items-center text-slate-400 text-xs">
        <ArrowDown className="w-4 h-4 animate-bounce text-orange-400" />
      </div>
    </section>
  );
};
