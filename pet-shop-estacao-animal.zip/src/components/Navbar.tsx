import React, { useState, useEffect } from 'react';
import { ShoppingBag, MessageCircle, Menu, X, Heart } from 'lucide-react';
import { BUSINESS_INFO, createWhatsAppUrl } from '../data/petData';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ cartCount, onOpenCart }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Produtos', href: '#produtos' },
    { label: 'Galeria', href: '#galeria' },
    { label: 'Contato', href: '#contato' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#FAF8F5]/90 backdrop-blur-md shadow-sm border-b border-orange-950/5 py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark */}
          <a
            href="#inicio"
            className="flex items-center gap-2.5 text-slate-900 group whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#EA580C] rounded-lg"
          >
            <div className="w-10 h-10 rounded-2xl bg-[#EA580C] text-white flex items-center justify-center shadow-md shadow-orange-600/20 group-hover:scale-105 transition-transform">
              <span className="text-xl">🐾</span>
            </div>
            <div className="flex flex-col">
              <span className="font-display text-xl font-bold tracking-tight text-slate-900">
                Estação Animal
              </span>
              <span className="text-[11px] font-medium text-orange-700/80 -mt-1 font-body">
                Pet Shop & Boutique
              </span>
            </div>
          </a>

          {/* Zone 2: Clean 4-5 Navigation Links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-semibold text-slate-700 font-body">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="whitespace-nowrap shrink-0 hover:text-[#EA580C] transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-[#EA580C] hover:after:w-full after:transition-all after:duration-200"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Zone 3: Primary Action & Cart */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Cart Trigger */}
            <button
              onClick={onOpenCart}
              type="button"
              aria-label={`Abrir sacola de pedidos com ${cartCount} itens`}
              className="relative p-2.5 rounded-full bg-white text-slate-700 hover:text-[#EA580C] hover:bg-orange-50 transition-all border border-slate-200/80 shadow-xs focus-visible:ring-2 focus-visible:ring-[#EA580C]"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#EA580C] text-white text-[11px] font-bold rounded-full flex items-center justify-center shadow-xs animate-in zoom-in-50 duration-200">
                  {cartCount}
                </span>
              )}
            </button>

            {/* WhatsApp CTA */}
            <a
              href={createWhatsAppUrl('Olá! Gostaria de falar com a equipe do Pet Shop Estação Animal.')}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#EA580C] hover:bg-[#C2410C] text-white font-display text-sm font-semibold shadow-md shadow-orange-600/20 hover:shadow-lg hover:shadow-orange-600/30 hover:-translate-y-0.5 transition-all whitespace-nowrap shrink-0"
            >
              <MessageCircle className="w-4 h-4 fill-white/20" />
              <span>Conversar no WhatsApp</span>
            </a>

            {/* Mobile Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              type="button"
              aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
              className="md:hidden p-2 rounded-xl text-slate-700 hover:bg-orange-100/50 transition-colors"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#FAF8F5] border-b border-orange-950/10 px-6 py-6 space-y-4 shadow-xl animate-in slide-in-from-top-4 duration-200">
          <nav className="flex flex-col space-y-3 font-display text-base font-semibold text-slate-800">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-[#EA580C] py-2 transition-colors border-b border-slate-100 flex items-center justify-between"
              >
                <span>{link.label}</span>
                <span className="text-orange-400 text-xs">→</span>
              </a>
            ))}
          </nav>
          <div className="pt-2 space-y-2">
            <a
              href={createWhatsAppUrl('Olá! Gostaria de agendar um atendimento na Estação Animal.')}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 px-5 py-3 rounded-full bg-[#EA580C] text-white font-display font-semibold shadow-md"
            >
              <MessageCircle className="w-5 h-5 fill-white/20" />
              <span>Conversar no WhatsApp</span>
            </a>

            <a
              href="/pet-shop-estacao-animal.zip"
              download="pet-shop-estacao-animal.zip"
              className="w-full flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-800 font-display text-xs font-semibold transition-colors"
            >
              <span>📦 Baixar Projeto (.ZIP)</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
