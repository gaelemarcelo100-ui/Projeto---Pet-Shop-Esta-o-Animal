import React, { useState } from 'react';
import { motion } from 'motion/react';
import { MessageCircle, MapPin, Phone, ArrowUpRight, Send, CheckCircle2 } from 'lucide-react';
import { BUSINESS_INFO, createWhatsAppUrl } from '../data/petData';

export const ContactSection: React.FC = () => {
  const [tutorName, setTutorName] = useState('');
  const [petName, setPetName] = useState('');
  const [petType, setPetType] = useState('Cachorro');
  const [serviceType, setServiceType] = useState('Banho & Tosa');
  const [note, setNote] = useState('');

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const message = `Olá, Estação Animal!
Meu nome é *${tutorName || 'Tutor'}* e gostaria de agendar para o meu pet *${petName || 'meu pet'}* (${petType}):
- Serviço: *${serviceType}*
${note ? `- Detalhes: ${note}` : ''}
Gostaria de saber os horários disponíveis!`;

    const url = createWhatsAppUrl(message);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contato" className="py-24 sm:py-32 bg-white relative overflow-hidden">
      {/* Floating subtle paw decorative shapes */}
      <div className="absolute top-10 left-8 text-orange-200/40 text-4xl select-none pointer-events-none rotate-12">
        🐾
      </div>
      <div className="absolute top-1/2 right-6 text-orange-200/40 text-5xl select-none pointer-events-none -rotate-12">
        🐾
      </div>
      <div className="absolute bottom-12 left-1/3 text-orange-200/30 text-3xl select-none pointer-events-none rotate-45">
        🐾
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Big CTA Banner with warm gradient and floating paws */}
        <div className="mb-20 rounded-3xl bg-gradient-to-br from-[#EA580C] via-[#DC2626] to-[#C2410C] text-white p-8 sm:p-14 lg:p-16 relative overflow-hidden shadow-2xl shadow-orange-950/20">
          <div className="absolute -right-12 -bottom-12 w-64 h-64 rounded-full bg-white/10 blur-2xl pointer-events-none" />
          <div className="absolute right-12 top-8 text-white/10 text-8xl font-black select-none pointer-events-none">
            🐾
          </div>

          <div className="max-w-2xl relative z-10 space-y-6">
            <span className="inline-block text-xs font-bold tracking-widest uppercase bg-white/20 text-white px-3.5 py-1 rounded-full backdrop-blur-xs">
              Atendimento Humanizado
            </span>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold leading-tight">
              Seu pet tratado com carinho e respeito de verdade.
            </h2>
            <p className="text-white/90 text-base sm:text-lg font-body leading-relaxed">
              Fale agora com nossa equipe no WhatsApp, tire dúvidas ou agende o horário ideal para o seu bichinho.
            </p>
            <div className="pt-2">
              <a
                href={createWhatsAppUrl('Olá! Gostaria de agendar um horário para o meu pet na Estação Animal.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-3 px-8 py-4 rounded-full bg-white text-[#EA580C] hover:bg-orange-50 font-display text-base font-bold shadow-lg hover:shadow-xl hover:scale-105 active:scale-100 transition-all"
              >
                <MessageCircle className="w-5 h-5 fill-[#EA580C]" />
                <span>Conversar no WhatsApp</span>
              </a>
            </div>
          </div>
        </div>

        {/* Contact Info & Interactive Quick-Schedule Generator */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Direct Address & Contact Information (5 cols) */}
          <div className="lg:col-span-5 space-y-8">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#EA580C] bg-orange-50 px-3 py-1 rounded-full">
                Localização & Contato
              </span>
              <h3 className="mt-4 font-display text-2xl sm:text-3xl font-bold text-slate-900">
                Venha nos Visitar
              </h3>
              <p className="mt-2 text-slate-600 font-body text-base">
                Fácil acesso no bairro de Batista Campos, ambiente seguro e acolhedor.
              </p>
            </div>

            {/* Address Card */}
            <div className="p-6 bg-[#FAF8F5] rounded-3xl border border-orange-950/5 space-y-4">
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-orange-100 text-[#EA580C] flex items-center justify-center shrink-0 mt-0.5">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-display text-sm font-bold text-slate-900">
                    Endereço
                  </h4>
                  <p className="text-sm text-slate-700 font-body leading-relaxed mt-0.5">
                    {BUSINESS_INFO.address}
                  </p>
                </div>
              </div>

              <a
                href={BUSINESS_INFO.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#EA580C] hover:text-[#C2410C] font-display transition-colors"
              >
                <span>Abrir rota no Google Maps</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Phone Card */}
            <div className="p-6 bg-[#FAF8F5] rounded-3xl border border-orange-950/5 flex items-center justify-between">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-2xl bg-orange-100 text-[#EA580C] flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-display text-sm font-bold text-slate-900">
                    Telefone & WhatsApp
                  </h4>
                  <p className="text-sm font-bold text-slate-800 font-body">
                    {BUSINESS_INFO.phoneDisplay}
                  </p>
                </div>
              </div>

              <a
                href={createWhatsAppUrl('Olá!')}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-full bg-[#EA580C] hover:bg-[#C2410C] text-white transition-colors"
                aria-label="Abrir WhatsApp"
              >
                <MessageCircle className="w-4 h-4 fill-white/20" />
              </a>
            </div>
          </div>

          {/* Right Column: Pre-filled Agendamento Form to WhatsApp (7 cols) */}
          <div className="lg:col-span-7 bg-[#FAF8F5] rounded-3xl p-8 sm:p-10 border border-orange-950/5 shadow-xs">
            <div className="mb-6">
              <h3 className="font-display text-xl sm:text-2xl font-bold text-slate-900">
                Agendamento Rápido
              </h3>
              <p className="text-sm text-slate-600 font-body mt-1">
                Preencha os dados do seu pet e o pedido será enviado diretamente ao nosso WhatsApp.
              </p>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="tutorName" className="block text-xs font-bold text-slate-700 font-display mb-1.5">
                    Seu Nome *
                  </label>
                  <input
                    id="tutorName"
                    type="text"
                    required
                    value={tutorName}
                    onChange={(e) => setTutorName(e.target.value)}
                    placeholder="Ex: Maria Clara"
                    className="w-full px-4 py-3 rounded-xl bg-white border border-slate-200 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-[#EA580C] focus:border-transparent transition-all"
                  />
                </div>

                <div>
                  <label htmlFor="petName" className="block text-xs font-bold text-slate-700 font-display mb-1.5">
                    Nome do Pet *
                  </label>
                  <input
                    id="petName"
                    type="text"
                    required
                    value={petName}
                    onChange={(e) => setPetName(e.target.value)}
                    placeholder="Ex: Thor ou Mia"
                    className="w-full px-4 py-3 rounded-xl bg-white border border-slate-200 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-[#EA580C] focus:border-transparent transition-all"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="petType" className="block text-xs font-bold text-slate-700 font-display mb-1.5">
                    Espécie
                  </label>
                  <select
                    id="petType"
                    value={petType}
                    onChange={(e) => setPetType(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-white border border-slate-200 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-[#EA580C] focus:border-transparent transition-all"
                  >
                    <option value="Cachorro">Cachorro</option>
                    <option value="Gato">Gato</option>
                    <option value="Outro Pet">Outro Pet</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="serviceType" className="block text-xs font-bold text-slate-700 font-display mb-1.5">
                    Serviço de Interesse
                  </label>
                  <select
                    id="serviceType"
                    value={serviceType}
                    onChange={(e) => setServiceType(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-white border border-slate-200 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-[#EA580C] focus:border-transparent transition-all"
                  >
                    <option value="Banho & Hidratação">Banho & Hidratação</option>
                    <option value="Tosa na Tesoura">Tosa na Tesoura</option>
                    <option value="Consulta Veterinária">Consulta Veterinária</option>
                    <option value="Daycare / Creche">Daycare / Creche</option>
                    <option value="Spa Especial Felino">Spa Especial Felino</option>
                    <option value="Táxi Dog">Táxi Dog</option>
                    <option value="Compra de Produtos">Compra de Produtos</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="note" className="block text-xs font-bold text-slate-700 font-display mb-1.5">
                  Observações ou data de preferência (opcional)
                </label>
                <textarea
                  id="note"
                  rows={2}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Ex: Porte médio, prefere horário pela manhã."
                  className="w-full px-4 py-3 rounded-xl bg-white border border-slate-200 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-[#EA580C] focus:border-transparent transition-all"
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-full bg-[#EA580C] hover:bg-[#C2410C] text-white font-display text-sm font-bold shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>Enviar para o WhatsApp</span>
              </button>
            </form>
          </div>

        </div>

      </div>
    </section>
  );
};
