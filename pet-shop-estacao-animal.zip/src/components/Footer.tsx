import React from 'react';
import { MessageCircle, MapPin, Phone, Heart } from 'lucide-react';
import { BUSINESS_INFO, createWhatsAppUrl } from '../data/petData';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 text-slate-300 pt-20 pb-12 border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* 4 Columns Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 pb-16 border-b border-slate-800/80">
          
          {/* Col 1: Brand & Slogan (4 cols) */}
          <div className="lg:col-span-4 space-y-5">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-[#EA580C] text-white flex items-center justify-center shadow-lg shadow-orange-600/30">
                <span className="text-xl">🐾</span>
              </div>
              <span className="font-display text-xl font-bold tracking-tight text-white">
                Estação Animal
              </span>
            </div>
            
            <p className="font-display text-base text-slate-200 font-semibold leading-relaxed">
              {BUSINESS_INFO.slogan}
            </p>

            <p className="text-sm text-slate-400 font-body leading-relaxed">
              Mais do que um pet shop: um espaço seguro, afetuoso e com padrão técnico de excelência no Batista Campos, Belém.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <a
                href={createWhatsAppUrl('Olá! Gostaria de falar com o Pet Shop Estação Animal.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#EA580C] hover:bg-[#C2410C] text-white font-display text-xs font-bold transition-all shadow-md"
              >
                <MessageCircle className="w-4 h-4 fill-white/20" />
                <span>Falar no WhatsApp</span>
              </a>

              <a
                href="/pet-shop-estacao-animal.zip"
                download="pet-shop-estacao-animal.zip"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-display text-xs font-semibold transition-all border border-slate-700/80"
              >
                <span>📦 Baixar Código (.ZIP)</span>
              </a>
            </div>
          </div>

          {/* Col 2: Navigation Links (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <h4 className="font-display text-sm font-bold tracking-wider uppercase text-white">
              Navegação
            </h4>
            <ul className="space-y-2.5 text-sm font-body text-slate-400">
              <li>
                <a href="#inicio" className="hover:text-white transition-colors">Início</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">Serviços</a>
              </li>
              <li>
                <a href="#produtos" className="hover:text-white transition-colors">Produtos</a>
              </li>
              <li>
                <a href="#galeria" className="hover:text-white transition-colors">Galeria</a>
              </li>
              <li>
                <a href="#contato" className="hover:text-white transition-colors">Contato</a>
              </li>
            </ul>
          </div>

          {/* Col 3: Key Services (3 cols) */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="font-display text-sm font-bold tracking-wider uppercase text-white">
              Nossos Cuidados
            </h4>
            <ul className="space-y-2.5 text-sm font-body text-slate-400">
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">Banho & Hidratação Calmante</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">Tosa na Tesoura & Padrão</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">Consulta Veterinária Preventiva</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">Daycare & Socialização Canina</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">Spa Silencioso para Gatos</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">Táxi Dog Climatizado</a>
              </li>
            </ul>
          </div>

          {/* Col 4: Location & Contact (3 cols) */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="font-display text-sm font-bold tracking-wider uppercase text-white">
              Onde Estamos
            </h4>
            <div className="space-y-3 text-sm font-body text-slate-400">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#EA580C] shrink-0 mt-1" />
                <span>{BUSINESS_INFO.address}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#EA580C] shrink-0" />
                <span className="font-semibold text-slate-200">{BUSINESS_INFO.phoneDisplay}</span>
              </div>
              <div className="pt-2">
                <a
                  href={BUSINESS_INFO.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-orange-400 hover:text-orange-300 font-semibold"
                >
                  <span>Abrir no Google Maps →</span>
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 font-body gap-4">
          <p>
            © {new Date().getFullYear()} Pet Shop Estação Animal. Todos os direitos reservados.
          </p>
          <p className="flex items-center gap-1">
            Feito com <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500" /> para os pets de Belém do Pará.
          </p>
        </div>

      </div>
    </footer>
  );
};
